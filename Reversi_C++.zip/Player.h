#ifndef PLAYER_H
#define PLAYER_H
#include <iostream>
#include<ctime>
#include <cstdlib>


using namespace std;

class Player
{
    int serialnumber;
    double placex,placey,vx,vy,best,bestx,besty;
    public:
        Player();
        Player(int name,double x,double y,double speedx,double speedy,double bestx,double besty,double best);
        Player(const Player& pl);
        virtual ~Player();
        Player& operator=(const Player& pl);
        void copyfrom(const Player&);
        void SetName(int name);
        int GetName();
        void SetPlacex(double x);
        double GetPlacex();
        void SetPlacey(double y);
        double GetPlacey();

        double getBest() const {return best;}
        void setBest(double best) {this->best = best;}
        double getVx() const {return vx;}
        void setVx(double vx) {this->vx = vx;}
        double getVy() const {return vy;}
        void setVy(double vy) {this->vy = vy;}
        void updatespeed(double globalx,double globaly);
		double getBestx(){return bestx;}
		void setBestx(double x){bestx =x;}
		double getBesty(){return besty;}
		void setBesty(double y){besty =y;}
		
        
};

#endif // PLAYER_H
