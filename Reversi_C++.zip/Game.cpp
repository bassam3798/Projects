#include "Game.h"

Game::Game() {
	time = 0;
	flagprint=0;
	//ctor
}

Game::~Game() {
	//dtor
}
//---------------------
void Game::simulation(char* input1, char* input2) {
	//FILE 1
	ifstream F(input1);
	if (!F) {
		cout << "ERROR: Invalid input." << endl;
		exit(1);
	}
	double x;
	int tst=-1;
	int maxiterations;
	Target target;
	string line;
	char* tmpx=new char[10];
	char* tmpy=new char[10];
	F >> tmpx >> tmpy >> maxiterations >> tst;
	//if there are more vars in the file print error and exit
	if(tst!=-1)
	 {
		cout << "ERROR: Invalid input." << endl;
		exit(1);
	}

	x=atof(tmpx);
	target.setX(x);
	delete tmpx;

	x=atof(tmpy);
	target.setY(x);
	delete tmpy;

	ifstream M(input2);
	if (!M) {
		cout << "EERROR: Invalid input." << endl;
		exit(1);
	}
	int numberofplayers;
	M >> numberofplayers ;
	Team* team= new Team(numberofplayers);
	double vx,vy,y;

	//init players
	for(int i=0;i<numberofplayers;i++)
	{
		M >> x >> y >>vx >> vy;
		Player player(i+1,x,y,vx,vy,x,y,distance(x,y,target.getX(),target.getY()));
		team->setplayerat(i,player);
	}
	//check if there are no vars in file2
	M >> tst;
	if(tst!=-1)
	{
		cout << "ERROR: Invalid input." << endl;
		exit(1);
	}
	Board *board=new Board();
	for(int i=0;i<numberofplayers;i++)
		board->addcounterat((int)team->getplayerat(i).GetPlacex(),(int)team->getplayerat(i).GetPlacey());
	
	
	
	//initilize global best
	double tmpdistance=0;
	tmpdistance=distance(team->getplayerat(0).GetPlacex(),team->getplayerat(0).GetPlacey(),target.getX(),target.getY());
	team->setBestdistance(tmpdistance);
	for(int i=0;i<numberofplayers;i++)
	{
		tmpdistance=distance(team->getplayerat(i).GetPlacex(),team->getplayerat(i).GetPlacey(),target.getX(),target.getY());
		if(tmpdistance<team->getBestdistance())
			team->setBestdistance(tmpdistance);
	}
	
	
	
	int i;
	//if the number of the operations is 0
	if(maxiterations==0)
	{
		cout << "0" << endl;
		//print the players places once because there is no simulations to do
		for(i=0;i<numberofplayers-1;i++)
		{
			printdouble(team->getplayerat(i).GetPlacex());
			cout << " ";
			printdouble(team->getplayerat(i).GetPlacey());
			cout << endl;
		}
		printdouble(team->getplayerat(numberofplayers-1).GetPlacex());
		cout << " ";
		printdouble(team->getplayerat(numberofplayers-1).GetPlacey());
			
		return;
	}
	
	//-----------------------------------------------------------------------------------------------------------
	//tmp places to save prev places so we can use them in the speed calculation
	double tmpplacex,tmpplacey;
	int flag=0;
	for(time=0;time<maxiterations;time++)
	{
		for(int i=0;i<numberofplayers;i++)
		{
			if((int)team->getplayerat(i).GetPlacex()==(int)target.getX()&&(int)team->getplayerat(i).GetPlacey()==(int)target.getY())
				flag=1;
			if(time==maxiterations-1)
				flag=1;
			if(flag==1)
			{
				cout << time+1 << endl;
				for(int i=0;i<numberofplayers;i++)
				{
					printdouble(team->getplayerat(i).GetPlacex());
					cout << " ";
					printdouble(team->getplayerat(i).GetPlacey());
					cout << endl;
					flagprint=1;
				}
				return;
			}
			//calculate the distance between the target and every player to know the best distance
			tmpdistance=distance(team->getplayerat(i).GetPlacex(),team->getplayerat(i).GetPlacey(),target.getX(),target.getY());
			//update the tmp place so we can ude it in the calculation
			tmpplacex=team->getplayerat(i).GetPlacex();
			tmpplacey=team->getplayerat(i).GetPlacey();
			//sub 1 from the cell that the player in  place i exists so we can know if he is moving a cell
			board->subcounterat((int)team->getplayerat(i).GetPlacex(),(int)team->getplayerat(i).GetPlacey());
			//update the place of the player in place i
			team->updateplace(i);
			//update the speed of the player un the place i
			team->updatespeed(i,tmpplacex,tmpplacey);
			//add the cell counter by one ,the player's place
			board->addcounterat((int)team->getplayerat(i).GetPlacex(),(int)team->getplayerat(i).GetPlacey());
			//check if the distance between the player and the target is shorter than the best personal distance and update 
			if(tmpdistance<(team->getplayerat(i).getBest()))
			{
				team->setpersonalbestx(i,team->getplayerat(i).GetPlacex());
				team->setpersonalbesty(i,team->getplayerat(i).GetPlacey());
				team->setplayerbest(i,tmpdistance);
			}
			//check if the distance between the player and the target is shorter than the global best and update  
			if(tmpdistance<(team->getBestdistance()))
			{
				team->setGlobalbestx(team->getplayerat(i).GetPlacex());
				team->setGlobalbesty(team->getplayerat(i).GetPlacey());
				team->setBestdistance(tmpdistance);
			}
			
		}
		
	}
	
}
//----------------------------------------------------------------------
//calculate the distance between a and b
double Game::distance(double ax,double ay,double bx,double by)
{
	double distance;
	distance=sqrt(pow(ax-bx,2)+pow(ay-by,2));
	return distance;
}
//-----------------------------------------------------------------------
//print fixed double 
void Game::printdouble(double number)
{
	double x=number;
	
	
	if((int)(x*100)%10==0)
	{
		if((int)(x*10)%10==0)
			cout <<  (int)x;
		else
			cout << fixed << setprecision(1) << x;
		return;
	}
	cout << fixed << setprecision(2) <<  x;
	
	return;
	
}