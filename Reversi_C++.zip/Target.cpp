/*
 * Target.cpp
 *
 *  Created on: 4 בדצמ 2018
 *      Author: משתמש
 */

#include "Target.h"

Target::Target() {
	srand(time(NULL));
	x=((double) (rand()) / RAND_MAX);
	y=((double) (rand()) / RAND_MAX);
	// TODO Auto-generated constructor stub

}
Target::Target(const Target& target)
{
	*this=target;
}

Target::~Target() {
	// TODO Auto-generated destructor stub
}

double Target::getX() const {
		return x;
	}

	void Target::setX(double x) {
		this->x = x;
	}

	double Target::getY() const {
		return y;
	}

	void Target::setY(double y) {
		this->y = y;
	}

	Target& Target::operator=(const Target& target)
	{
		this->x=x;
		this->y=y;
		return (*this);
	}
