/*
 * Cell.cpp
 *
 *  Created on: 9 בדצמ 2018
 *      Author: משתמש
 */

#include "Cell.h"

Cell::Cell() {
	// TODO Auto-generated constructor stub
	x=0;
	y=0;
	counter = 0;
}
//------------------------------------------------
Cell::Cell(int x,int y,int counter)
{
	this->x=x;
	this->y=y;
	this->counter=counter;
}
//-------------------------------------------------
Cell::~Cell() {
	// TODO Auto-generated destructor stub
}
//------------------------------------------------
Cell& Cell::operator ++() {
	*this = *this + 1;
	return *this;
}
//-------------------------------------------------
//postfix ++: adds 1 to each element
const Cell Cell::operator++(int) {
	Cell temp = *this;
	*this = *this + 1;
	return temp; // the result before addition
}
//--------------------------------------------------
Cell& Cell::operator --() {
	*this = *this - 1;
	return *this;
}
//---------------------------------------------------
const Cell Cell::operator--(int) {
	Cell temp = *this;
	*this = *this - 1;
	return temp; // the result before addition
}
//-----------------------------------------------------
Cell& Cell::operator =(const Cell& cell)
{
	if (this == &cell) {
	return (*this);
	}
	this->counter=cell.counter;
	this->x=cell.x;
	this->y=cell.y;
	return (*this);
}
//----------------------------------------------------
Cell::Cell(const Cell& cell)
{
	*this=cell;
}
//----------------------------------------------------
Cell& Cell::operator +(int x)
{
	this->counter+=1;
	return (*this);
}
//-----------------------------------------------------
Cell& Cell::operator-(int x)
{
	this->counter-=x;
	return(*this);
}
