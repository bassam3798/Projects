/*
 * Team.cpp
 *
 *  Created on: 9 בדצמ 2018
 *      Author: משתמש
 */

#include "Team.h"

Team::Team():numberofplayers(1),team(new Player[numberofplayers]),globalbestx(0),globalbesty(0) ,bestdistance(0){
}
//---------------------------------------
Team::~Team() {
	// TODO Auto-generated destructor stub
	freeMemory();
}
//---------------------------------------
Team::Team(int numberofplayers)
{
	this->numberofplayers=numberofplayers;
	team=new Player[numberofplayers];
	globalbestx=globalbesty=bestdistance=0;
}
//---------------------------------------
Team::Team(const Team& team)
{
	*this=team;
}
//---------------------------------------
void Team::setplayerat(int index,Player player)
{
	team[index]=player;
}
//----------------------------------------
Team& Team::operator =(const Team& tm)
{
	if (this == &tm) {
	return (*this);
	}
	// free the old memory
	freeMemory();
	// copy the new memory
	copyFrom(tm);
	return (*this);
}
//-----------------------------------------
void Team::freeMemory()
{
	delete(team);
}
//------------------------------------------
void Team::copyFrom(const Team& tm)
{
	this->numberofplayers=numberofplayers;
	team=new Player[tm.numberofplayers];
}
//----------------------------------------
void Team::setplayerbest(int index,double best)
{
	team[index].setBest(best);
	return;
}
//---------------------------------------
void Team::updateplace(int index)
{
	team[index].SetPlacex(team[index].GetPlacex()+team[index].getVx());
	if(team[index].GetPlacex()>29)
		team[index].SetPlacex(29);
	if(team[index].GetPlacex()<0)
		team[index].SetPlacex(0);

	team[index].SetPlacey(team[index].GetPlacey()+team[index].getVy());
	if(team[index].GetPlacey()>60)
		team[index].SetPlacey(60);
	if(team[index].GetPlacey()<0)
		team[index].SetPlacey(0);
	return;
}
//---------------------------------------
void Team::updatespeed(int index,double x,double y)
{
	srand(time(NULL));
	double r1=((double) (rand()) / RAND_MAX);
	double r2=((double) (rand()) / RAND_MAX);
	team[index].setVx(0.25*team[index].getVx()+r1*(team[index].getBestx()-x)+r2*(globalbestx-x));
	team[index].setVy(0.25*team[index].getVy()+r1*(team[index].getBesty()-y)+r2*(globalbesty-y));
	return;
}
