#ifndef BOARD_H
#define BOARD_H
#include"Cell.h"

class Board
{

    Cell** board;
    public:
    	static const int COLNS=30;
        static const int ROWS=61;
        Board();
        Board(Board& b);
        virtual ~Board();
        Board& operator=(const Board& b);
        int operator()( int x,int y);
        void freememory();
        void copyfrom(const Board& b);
        Cell** GetBoard(){return board;};
        void addcounterat(int i,int j);
        void subcounterat(int i,int j);

};

#endif // BOARD_H
