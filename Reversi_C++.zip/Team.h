/*
 * Team.h
 *
 *  Created on: 9 בדצמ 2018
 *      Author: משתמש
 */

#ifndef TEAM_H_
#define TEAM_H_
#include"Player.h"
#include<iostream>
#include<cstring>
#include <cstdlib>

class Team {
	int numberofplayers;
	Player* team;
	double globalbestx,globalbesty,bestdistance;
public:
	Team();
	Team(int numberofplayers);
	Team(const Team& team);
	virtual ~Team();
	void setplayerat(int index,Player player);
	Player getplayerat(int index){return team[index];};
	Team& operator=(const Team& );
	void freeMemory();
	void copyFrom(const Team& tm);

	int getNumberofplayers() const {return numberofplayers;}
	void setplayerbest(int index,double best);
	void setNumberofplayers(int numberofplayers) {this->numberofplayers = numberofplayers;}

	double getGlobalbestx() const {return globalbestx;}
	void setGlobalbestx(double globalbestx) {this->globalbestx = globalbestx;}

	double getGlobalbesty() const {return globalbesty;}
	void setGlobalbesty(double globalbesty) {this->globalbesty = globalbesty;}

	void updateplace(int index);
    void updatespeed(int index,double x,double y);

	double getBestdistance() const {return bestdistance;}

	void setBestdistance(double bestdistance) {this->bestdistance = bestdistance;}
	void setpersonalbestx(int index , double x){team[index].setBestx(x);}
	void setpersonalbesty(int index , double y){team[index].setBestx(y);}
};

#endif /* TEAM_H_ */
