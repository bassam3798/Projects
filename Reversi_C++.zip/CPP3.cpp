#include<iostream>
#include<cstdlib>
#include<ctime>
#include"Game.h"
#include <fstream>

using namespace std;

int main(int argc, char* argv[]) {

	//check if the number of the args are correct
	if (argc != 3) {
		cerr << "ERROR: Invalid input." << endl;
		exit(1);
	}
	Game* game=new Game();
	game->simulation(argv[1], argv[2]);
	delete(game);
	return 0;
}
