/*
 * Cell.h
 *
 *  Created on: 9 בדצמ 2018
 *      Author: משתמש
 */

#ifndef CELL_H_
#define CELL_H_

class Cell {
	int counter;
	int x,y;
public:
	Cell();
	Cell(int x,int y,int counter);
	Cell(const Cell& cell);
	virtual ~Cell();
	Cell& operator=(const Cell& cell);
	Cell& operator+(int);
	Cell& operator++();
	const Cell operator++(int);
	Cell& operator-(int);
	Cell& operator--();
	const Cell operator--(int);

	int getCounter() const {return counter;}
	void setCounter(int counter) {this->counter = counter;}

	int getX() const {return x;}

	void setX(int x) {this->x = x;}

	int getY() const {return y;}

	void setY(int y) {this->y = y;}
};

#endif /* CELL_H_ */
