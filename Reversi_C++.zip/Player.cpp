#include"Player.h"

Player::Player()
{
	serialnumber=placex=placey=vx=vy=bestx=besty=best=0;
    //ctor
}
Player::Player(const Player& pl)
{
    *this=pl;
}
//-------------------------------
Player::Player(int name,double x,double y,double speedx,double speedy,double bestx,double besty,double best)
{
	serialnumber=name;
    placex=x;
    placey=y;
    vx=speedx;
    vy=speedy;
    this->best=best;
	this->bestx=bestx;
	this->besty=besty;
}
//-------------------------------
Player::~Player()
{
    //dtor
}
//------------------------
Player& Player::operator=(const Player& pl)
{
    if(this==&pl)
        return (*this);
    //there's nothing to free
    copyfrom(pl);
    return (*this);

}
//--------------------------
void Player::copyfrom(const Player& pl)
{
    serialnumber=pl.serialnumber;
    placex=pl.placex;
    placey=pl.placey;
    vx=pl.vx;
    vy=pl.vy;
	best=pl.best;
	bestx=pl.bestx;
	besty=pl.besty;
}
//----------------------
void Player::SetName(int name)
{
    this->serialnumber=name;
    return;
}
//-----------------------
int Player::GetName()
{
    return serialnumber;
}
//------------------------
void Player::SetPlacex(double x)
{
    placex=x;
    return;
}
//--------------------------
double Player::GetPlacex()
{
    return placex;
}
//--------------------------
void Player::SetPlacey(double y)
{
    placey=y;
    return;
}
//---------------------------
double Player::GetPlacey()
{
    return placey;
}

//-------------------------
