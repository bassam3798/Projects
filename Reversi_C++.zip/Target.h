/*
 * Target.h
 *
 *  Created on: 4 בדצמ 2018
 *      Author: משתמש
 */

#ifndef TARGET_H_
#define TARGET_H_
#include<ctime>
#include <cstdlib>

class Target {
	double x, y;
public:
	Target();
	Target(const Target& target);
	Target& operator=(const Target& target);
	Target(double x,double y){this->x=x; this->y=y;};
	virtual ~Target();
	double getX() const;
	void setX(double x);
	double getY() const;
	void setY(double y);

};

#endif /* TARGET_H_ */
