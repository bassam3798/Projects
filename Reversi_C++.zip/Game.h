#ifndef GAME_H
#define GAME_H
#include "Player.h"
#include "Board.h"
#include "Target.h"
#include "Team.h"
#include<iostream>
#include <iomanip>
#include<cstdlib>
#include<ctime>
#include<cmath>
#include<fstream>
#include <sstream>
#include <string>
#include <cmath>

using namespace std;


//there is no need for big 3 here
class Game
{
	int time,flagprint;
    public:
        Game();
        virtual ~Game();
        void simulation(char*,char*);
        double distance(double,double,double,double);
		void printdouble(double number);
};

#endif // GAME_H
