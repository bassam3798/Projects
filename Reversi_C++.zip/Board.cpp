#include "Board.h"

Board::Board()
{
    board=new Cell*[ROWS];
    int i,j;
    for(i=0;i<ROWS;i++)
        board[i]=new Cell[COLNS];
    for(i=0;i<ROWS;i++)
    	for(j=0;j<COLNS;j++)
    	{
    		board[i][j].setX(i);
    		board[i][j].setY(j);
    	}
    //ctor
}
//----------------------------
Board::Board(Board& b)
{
    *this=b;
}
//-----------------------------
Board::~Board()
{
    freememory();
    //dtor
}
//-----------------------------
Board& Board::operator=(const Board& b)
{
    if(this==&b)
        return (*this);
    freememory();
    copyfrom(b);
    return (*this);
}
//-----------------------------
void Board::freememory()
{
    for (int i = 0; i <ROWS ; i++) {
        delete board[i];
    }
    delete [] board;
}
//--------------------------------
void Board::copyfrom(const Board& b)
{
    int i, j;
    board = new Cell* [ROWS];
    for (i = 0; i < ROWS; i++) {
        board[i] = new Cell[COLNS];
    }
    for (i = 0; i < ROWS; i++) {
        for (j = 0; j < COLNS; j++) {
            board[i][j] = b.board[i][j];
        }
    }
}
//-----------------------------------
int Board::operator()(int x,int y)
{
	return board[x][y].getCounter();
}
//-----------------------------------
void Board::addcounterat(int i,int j)
{
	board[i][j]++;
	return;
}
//-----------------------------------
void Board::subcounterat(int i,int j)
{
	board[i][j]--;
	return;
}
