﻿using System;

namespace FourInRowLibrary {
    public class Class1 {
    }
}
