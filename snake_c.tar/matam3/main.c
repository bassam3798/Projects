#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include<time.h>

#include "misc.h"
#include "Position.h"
#include "Screen.h"
#include "Snake.h"
#include "Apple.h"

/************************************************************************************************************************/
int main()
{
  
  time_t t;
  srand((unsigned)time(&t));
  
  int count=0;
	// Create a screen
	Screen screen = CreateScreen(120, 35);
	// Create a snake of size 30
	Snake snake = CreateSnake(60, 20, 4);
	// Initial direction of movement is Right
	Direction direction = Right;
  Apple apple =CreateApple(0,0);
  int flag=0;
	// Make sure the STDIN buffer is empty
	fflush(stdin);
  Position help=CreatePosition(0,0);
	// As long as we can draw a legal screen, keep on going
	while(DrawScreen(screen, snake)) {
		system("clear");
   if(flag==0)
   {
      do
     { 
             
            SetX(help,(rand()%GetRow(screen)));
            SetY(help,(rand()%GetRow(screen))); 
     }
     while(!(ScreenPositionEmpty(screen,help)));
     SetApple(apple,help);
     flag=1;
   }
   DrawApple(screen,apple);
		// Print the current screen 
		PrintScreen(screen, stdout);
		// Wait 0.2 seconds
		sleep_ms(200);
		// If the user hit a key - read it and change direction if the key represent a legal direction
		if(kbhit()) {
			char ch = getchar();
			if((ch == Left) || (ch == Right) || (ch == Up) || (ch == Down)) {
				direction = (Direction)ch;
			}
			// Else - we will leave the original direction
		}
   if((GetX(SnakeNext(snake,direction))==GetX(GetApple(apple)))&&(GetY(SnakeNext(snake,direction))==GetY(GetApple(apple))))
   {
		snake=MoveSnake(snake, direction,true);
    flag=0;
    count++;
   }
   else
     snake=MoveSnake(snake, direction,false);
   
	}
  printf("you ate %d apples! good job \n",count);
	DeleteSnake(snake);
  DestroyApple(apple);
  DeleteScreen(screen);
 
	return 0;
}
