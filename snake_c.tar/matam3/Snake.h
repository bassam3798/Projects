#ifndef SNAKE_H
#define SNAKE_H

#include<stdbool.h>
#include "Position.h"

typedef enum {Up='i', Down='m', Left='j', Right='l'} Direction;

typedef struct Snake* Snake ;

void CreatNewSnake(Snake s,int size);
//get the direction of a snake
Direction GetMovment(Snake s);
//set the direction in struct screen
void SetMovment(Snake s,Direction movement);
//get the [i] position of a snake
Position GetSnake(Snake s,int i);
//set the wanted snake
void SetSnake(Snake s,Position* snake);
//get the length of snake
int GetLingth(Snake s);
//set length
void SetLingth(Snake s,unsigned int length);
//constructor
Snake	CreateSnake(int x, int y,unsigned int length);
//destructor
void	DeleteSnake(Snake snake);
//move the snake one step forward 
Snake MoveSnake(Snake snake, Direction direction,bool elongate);
//
Position SnakeNext(Snake snake ,Direction direction);

#endif
