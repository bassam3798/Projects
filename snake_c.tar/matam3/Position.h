#ifndef POSITION_H
#define POSITION_H

/************************************************************************************************************************/
typedef struct Position* Position;
// Constructor
Position CreatePosition(int x, int y);
//get the x of a position
int GetX(Position p);
//set x in the wanted position
void SetX(Position p,int x);
//get the y of a position
int GetY(Position p);
//set y in the wanted position
void SetY(Position p,int y);
// Destructor
void DeletePosition(Position pos);

#endif
