#include "Position.h"
#include "misc.h"
#include <stdio.h>
#include <stdlib.h>
struct Position {
	int x;
  int y;
} ;

int GetX(Position p)
{
    return p->x;
}
void SetX(Position p, int x)
  {
	 p->x=x;
	}

int GetY(Position p)
    {
    return p->y;
    }
void SetY(Position p, int y)
    {
	   p->y=y;
    }

/************************************************************************************************************************/
Position CreatePosition(int x, int y) {
	Position pos = (Position)AllocateMemory(sizeof(struct Position), __FILE__, __LINE__);
	SetX(pos,x);
	SetY(pos,y);

	return pos;
}

/************************************************************************************************************************/
void DeletePosition(Position pos) {
	free(pos);
}
