#include "Snake.h"
#include "misc.h"
#include <stdio.h>
#include <stdlib.h>
#include<stdbool.h>


struct Snake {
        Direction	movement;
        Position*	snake;
	unsigned int	length;
} ;

Direction GetMovment(const Snake s)
{
  return s->movement;
}
  void SetMovment(Snake s,Direction movement)
{
  s->movement=movement;
}
Position GetSnake(const Snake s,int i)
{
  return s->snake[i];
}
void SetSnake(Snake s,Position* snake)
{
  s->snake=snake;
}


unsigned int GetLength(const Snake s)
{
return s->length;
}
void SetLength(Snake s,unsigned int length)
{
  s->length=length;
}
/************************************************************************************************************************/
Position SnakeNext(Snake snake ,Direction direction)
{
  Position position;
  position=CreatePosition(GetX(GetSnake(snake,0)),GetY(GetSnake(snake,0)));
  switch(direction)
  {
    case Up:
      SetY(position,GetY(position)-1);
      break;
    
    case Down:
      SetY(position,GetY(position)+1);
      break;
    
    case Right:
      SetX(position,GetX(position)+1);
      break; 
    
    case Left:
      SetX(position,GetX(position)-1);
      break;
  }
  return position;
}
/************************************************************************************************************************/
Snake	CreateSnake(int x, int y,unsigned int length)
{
	int i;
        Snake s = (Snake)AllocateMemory(sizeof(struct Snake), __FILE__, __LINE__);
        s->snake=(Position *)AllocateMemory(sizeof(Position)*length,__FILE__,__LINE__);
        SetMovment(s,Right);
        s->length=length;
    	for(i=0; i<length; i++,x--) 
        s->snake[i]=CreatePosition(x,y);
        return s;
}

/************************************************************************************************************************/
void DeleteSnake(Snake s)
{
  int i;
  for(i=GetLength(s)-1;i>=0;i--)
  {
    DeletePosition(GetSnake(s,i));
  }
	free(s);
}

/************************************************************************************************************************/
Snake MoveSnake(Snake snake, Direction direction,bool elongate)
{
	int i;
        Position pos = GetSnake(snake,0);
        Position temp1, temp2;
        temp1=CreatePosition(GetX(pos),GetY(pos));
  
        if(snake->movement == Down && direction == Up)
		direction = Down;
	if(snake->movement == Up && direction == Down)
		direction = Up;
	if(snake->movement == Left && direction == Right)
		direction = Left;
	if(snake->movement == Right && direction == Left)
		direction = Right;
        
        if((direction != Up) && (direction != Down) && (direction != Left) && (direction != Right))
                direction = snake->movement;
        
        if(elongate)
        {
          snake->snake=(Position *)realloc(snake->snake,(snake->length+1)*sizeof(Position));
          /*SetX(GetSnake(snake,0),GetX(pos));
          SetY(GetSnake(snake,0),GetY(pos));*/
          snake->snake[snake->length]=CreatePosition(0,0);
          snake->length++;
         } 
        
        // Move head
        switch(direction) {
                case Up:
                       /* if(elongate==true)
                          SetY(GetSnake(snake,0),GetY(GetSnake(snake,0))-1);*/
                        SetY(GetSnake(snake,0),GetY(GetSnake(snake,0))-1);
                        break;
                case Down:
                       /* if(elongate==true)
                          SetY(GetSnake(snake,0),GetY(GetSnake(snake,0))+1);*/
                         SetY(GetSnake(snake,0),GetY(GetSnake(snake,0))+1);
                        break;
                case Right:
                      /* if(elongate==true)
                          SetX(GetSnake(snake,0),GetX(GetSnake(snake,0))+1);*/
                         SetX((GetSnake(snake,0)),GetX(GetSnake(snake,0))+1);
                        break;
                case Left:
                      /* if(elongate==true)
                          SetX(GetSnake(snake,0),GetX(GetSnake(snake,0))-1);*/
                        SetX((GetSnake(snake,0)),GetX(GetSnake(snake,0))-1);
                        break;
                default:
                        return snake;
        }
  temp2=CreatePosition(1,1);
        // Move rest of the body
	for(i=1; i<GetLength(snake); i++) {
                SetX(temp2,GetX(GetSnake(snake,i)));
                SetY(temp2,GetY(GetSnake(snake,i)));
                SetX(GetSnake(snake,i),GetX(temp1));
                SetY(GetSnake(snake,i),GetY(temp1));
                SetX(temp1,GetX(temp2));
                SetY(temp1,GetY(temp2));
        }

        SetMovment(snake,direction);
  DeletePosition(temp2);
  DeletePosition(temp1);
  return snake;
}
