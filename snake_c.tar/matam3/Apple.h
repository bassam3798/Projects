#ifndef APPLE_H
#define APPLE_H

#include"Position.h"
#include <stdio.h>


typedef struct Apple *Apple ;

//constructor
Apple CreateApple(int x,int y);
//Get position of apple
Position GetApple(Apple apple);
//set apple in the wanted position
void SetApple(Apple apple ,Position position);
//free apple
void DestroyApple(Apple apple);

#endif