#include "Screen.h"
#include "misc.h"
#include <stdlib.h>
struct Screen{
        int nrow;
        int ncol;
        char** screen;
} ;
int GetRow(Screen sc){
  return sc->nrow;
}
/*********************************/
void SetRow(Screen sc,int nrow)
{
  sc->nrow=nrow;
  return;
}
/*********************************/
int GetCol(Screen sc){
  return sc->ncol;
}
/********************************/
void SetCol(Screen sc,int ncol)
{
  sc->ncol=ncol;
  return;
}
/*******************************/
char GetScreen(Screen sc,int i,int j)
{
  return sc->screen[i][j];
}
/*******************************/
void SetScreen(Screen sc,int i,int j,char screen)
{
  sc->screen[i][j]=screen;
  return;
}
/************************************************************************************************************************/
 bool ScreenPositionEmpty(Screen screen,Position position)
 {
   if(screen->screen[GetX(position)][GetY(position)]!=' ')
       return false;
   return true;
 }
/************************************************************************************************************************/
bool DrawApple(Screen screen ,Apple apple)
{
    if(!(ScreenPositionEmpty(screen,GetApple(apple))))
      return false;
  screen->screen[GetX(GetApple(apple))][GetY(GetApple(apple))]='@'; 
  return true;
}
/************************************************************************************************************************/
Screen CreateScreen(int ncol, int nrow)
{

        Screen res = (Screen)malloc(sizeof(struct Screen));
 
        SetRow(res,nrow);
        SetCol(res,ncol);

        res->screen = (char**)AllocateMemory2D(nrow, ncol, sizeof(char), __FILE__, __LINE__);
        return res;
}

/************************************************************************************************************************/
void DeleteScreen(Screen screen)
{
	FreeMemory2D((void**)(screen->screen));
	free(screen);
 return;
}

/************************************************************************************************************************/
bool DrawScreen(const Screen screen, Snake snake)
{
        int r, c;

        // Clean the screen
       for(c=0; c<screen->ncol; c++) {
                screen->screen[c][0] = '#';
                for(r=1; r<screen->nrow-1; r++) {
                        if((c==0) || (c==screen->ncol-1))
                                screen->screen[c][r] = '#';
                        else
                                screen->screen[c][r] = ' ';
                }
                screen->screen[c][screen->nrow-1] = '#';
        }

        if(GetScreen(screen,GetX(GetSnake(snake,0)),GetY(GetSnake(snake,0)))!=' ')
                return false;
        SetScreen(screen,GetX(GetSnake(snake,0)),GetY(GetSnake(snake,0)),'+');

       unsigned int i;
	  const Position p = CreatePosition(GetX(GetSnake(snake, 1)), GetY(GetSnake(snake, 1)));
     unsigned int help=GetLength(snake);
	    for(i=1; i<help; i++)
      {
               SetX(p, GetX(GetSnake(snake, i)));
               SetY(p, GetY(GetSnake(snake, i)));
               if((GetScreen(screen,GetX(p),GetY(p)) != ' ')) 
               {
                       DeletePosition(p);
                        return false;
                        }
               SetScreen(screen,GetX(p),GetY(p),'*');
        }
        DeletePosition(p);
        return true;
}

/************************************************************************************************************************/
void PrintScreen(const Screen screen, FILE* fp)
{
        int r, c;

        for(r=0; r<GetRow(screen); r++) {
                for(c=0; c<GetCol(screen); c++) {
                        putc(GetScreen(screen,c,r), fp);
                }
                putc('\n', fp);
        }
}