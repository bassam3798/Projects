#include "Apple.h"
#include "misc.h"

#include <stdio.h>
#include <stdlib.h>

struct Apple{
	Position position;
} ;
/******************************************************/
Position GetApple(Apple apple)
{
  return apple->position;
}
/****************************************************/
void SetApple(Apple apple ,Position position)
{
  apple->position=position;
  return;
}
/****************************************************/
Apple CreateApple(int x,int y)
{
  Apple apple=(Apple)AllocateMemory(sizeof(struct Apple), __FILE__, __LINE__);
  apple->position=(Position)AllocateMemory(sizeof(Position), __FILE__, __LINE__);
  SetX(apple->position,x);
  SetY(apple->position,y);
  return apple;
}
/****************************************************/
void DestroyApple(Apple apple)
{
  free(apple->position);
  free(apple);
  return;
}