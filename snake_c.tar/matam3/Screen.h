#ifndef SCREEN_H
#define SCREEN_H

#include"Apple.h"
#include "Snake.h"
#include <stdbool.h>
#include <stdio.h>
/**********************************************************/
typedef struct Screen* Screen ;
//get number of rows
int GetRow(Screen sc);
//put the number of rows in struct screen
void SetRow(Screen sc,int nrow);
//get number of cols
int GetCol(Screen sc);
//put the number of cols in struct screen
void SetCol(Screen sc,int ncol);
//get the char in the [i][j] place on screen
char GetScreen(Screen sc,int i,int j);
//put a char in the wanted [i][j] place on screen
void SetScreen(Screen sc,int i,int j,char screen);
//check if the screen in the wanted position is empty
bool ScreenPositionEmpty(Screen snreen,Position position);
//constructor
Screen CreateScreen(int ncol, int nrow);
//destructor
void DeleteScreen(Screen screen);
//fill the screen with characters return true if it succeded
bool DrawScreen(const Screen screen, Snake snake);
//print the screen after the draw
void PrintScreen(const Screen screen, FILE* fp);

#endif
